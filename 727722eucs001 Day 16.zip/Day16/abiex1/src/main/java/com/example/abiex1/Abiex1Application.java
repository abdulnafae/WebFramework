package com.example.abiex1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Abiex1Application {

	public static void main(String[] args) {
		SpringApplication.run(Abiex1Application.class, args);
		
	}

}
